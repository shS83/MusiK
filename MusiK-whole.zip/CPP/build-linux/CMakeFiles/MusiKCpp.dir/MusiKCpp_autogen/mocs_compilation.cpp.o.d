CMakeFiles/MusiKCpp.dir/MusiKCpp_autogen/mocs_compilation.cpp.o: \
 /home/shs/Code/MusiK/CPP/build-linux/MusiKCpp_autogen/mocs_compilation.cpp \
 /usr/include/stdc-predef.h
