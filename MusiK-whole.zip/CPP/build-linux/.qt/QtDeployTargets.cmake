set(__QT_DEPLOY_TARGETS "MusiKCpp")
set(__QT_DEPLOY_TARGET_MusiKCpp_FILE /home/shs/Code/MusiK/CPP/build-linux/MusiKCpp)
set(__QT_DEPLOY_TARGET_MusiKCpp_TYPE EXECUTABLE)
