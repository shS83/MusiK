CMakeFiles/MusiKCpp.dir/src/main.cpp.o: \
 /home/shs/Code/MusiK/CPP/src/main.cpp /usr/include/stdc-predef.h \
 /usr/include/qt6/QtWidgets/QTabWidget \
 /usr/include/qt6/QtWidgets/qtabwidget.h \
 /usr/include/qt6/QtWidgets/qtwidgetsglobal.h \
 /usr/include/qt6/QtGui/qtguiglobal.h /usr/include/qt6/QtCore/qglobal.h \
 /usr/include/c++/16/type_traits \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/c++config.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/cpu_defines.h \
 /usr/include/c++/16/pstl/pstl_config.h \
 /usr/include/c++/16/bits/version.h /usr/include/c++/16/cstddef \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/c++/16/utility /usr/include/c++/16/bits/stl_relops.h \
 /usr/include/c++/16/bits/stl_pair.h /usr/include/c++/16/bits/move.h \
 /usr/include/c++/16/bits/utility.h /usr/include/c++/16/compare \
 /usr/include/c++/16/concepts /usr/include/c++/16/initializer_list \
 /usr/include/c++/16/bits/intcmp.h \
 /usr/include/c++/16/ext/numeric_traits.h \
 /usr/include/c++/16/bits/cpp_type_traits.h \
 /usr/include/c++/16/ext/type_traits.h /usr/include/c++/16/cstdint \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/libc-header-start.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-intn.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h /usr/include/assert.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /usr/include/qt6/QtCore/qtcoreglobal.h \
 /usr/include/qt6/QtCore/qtversionchecks.h \
 /usr/include/qt6/QtCore/qtconfiginclude.h /usr/include/c++/16/version \
 /usr/include/qt6/QtCore/qconfig.h \
 /usr/include/qt6/QtCore/qtcore-config.h \
 /usr/include/qt6/QtCore/qtconfigmacros.h \
 /usr/include/qt6/QtCore/qtdeprecationdefinitions.h \
 /usr/include/qt6/QtCore/qcompilerdetection.h \
 /usr/include/qt6/QtCore/qprocessordetection.h \
 /usr/include/qt6/QtCore/qsystemdetection.h \
 /usr/include/qt6/QtCore/qtcoreexports.h \
 /usr/include/qt6/QtCore/qtdeprecationmarkers.h \
 /usr/include/qt6/QtCore/qtclasshelpermacros.h \
 /usr/include/qt6/QtCore/qtpreprocessorsupport.h \
 /usr/include/qt6/QtCore/qassert.h /usr/include/qt6/QtCore/qtnoop.h \
 /usr/include/qt6/QtCore/qtypes.h /usr/include/qt6/QtCore/qtversion.h \
 /usr/include/qt6/QtCore/qtypeinfo.h \
 /usr/include/qt6/QtCore/qcontainerfwd.h /usr/include/c++/16/limits \
 /usr/include/qt6/QtCore/qsysinfo.h /usr/include/qt6/QtCore/qlogging.h \
 /usr/include/qt6/QtCore/qflags.h /usr/include/qt6/QtCore/qcompare_impl.h \
 /usr/include/c++/16/algorithm /usr/include/c++/16/bits/stl_algobase.h \
 /usr/include/c++/16/bits/stl_iterator_base_types.h \
 /usr/include/c++/16/bits/iterator_concepts.h \
 /usr/include/c++/16/bits/ptr_traits.h \
 /usr/include/c++/16/bits/ranges_cmp.h \
 /usr/include/c++/16/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/16/bits/concept_check.h \
 /usr/include/c++/16/debug/assertions.h \
 /usr/include/c++/16/bits/stl_iterator.h /usr/include/c++/16/new \
 /usr/include/c++/16/bits/exception.h \
 /usr/include/c++/16/bits/new_except.h \
 /usr/include/c++/16/bits/exception_defines.h \
 /usr/include/c++/16/bits/stl_construct.h \
 /usr/include/c++/16/debug/debug.h \
 /usr/include/c++/16/bits/predefined_ops.h \
 /usr/include/c++/16/bits/stl_function.h \
 /usr/include/c++/16/backward/binders.h /usr/include/c++/16/bit \
 /usr/include/c++/16/bits/stl_algo.h \
 /usr/include/c++/16/bits/algorithmfwd.h \
 /usr/include/c++/16/bits/stl_heap.h \
 /usr/include/c++/16/bits/uniform_int_dist.h \
 /usr/include/c++/16/bits/stl_tempbuf.h /usr/include/c++/16/cstdlib \
 /usr/include/stdlib.h /usr/include/bits/waitflags.h \
 /usr/include/bits/waitstatus.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/bits/types/locale_t.h \
 /usr/include/bits/types/__locale_t.h /usr/include/sys/types.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/endian.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/byteswap.h \
 /usr/include/bits/uintn-identity.h /usr/include/sys/select.h \
 /usr/include/bits/select.h /usr/include/bits/types/sigset_t.h \
 /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-float.h /usr/include/c++/16/bits/std_abs.h \
 /usr/include/c++/16/bits/ranges_algo.h \
 /usr/include/c++/16/bits/ranges_algobase.h \
 /usr/include/c++/16/bits/ranges_base.h \
 /usr/include/c++/16/bits/max_size_type.h /usr/include/c++/16/numbers \
 /usr/include/c++/16/bits/invoke.h /usr/include/c++/16/bits/ranges_util.h \
 /usr/include/c++/16/pstl/glue_algorithm_defs.h \
 /usr/include/c++/16/pstl/execution_defs.h \
 /usr/include/qt6/QtCore/qatomic.h /usr/include/qt6/QtCore/qbasicatomic.h \
 /usr/include/qt6/QtCore/qatomic_cxx11.h \
 /usr/include/qt6/QtCore/qgenericatomic.h \
 /usr/include/qt6/QtCore/qyieldcpu.h /usr/include/c++/16/atomic \
 /usr/include/c++/16/bits/atomic_base.h \
 /usr/include/c++/16/bits/atomic_lockfree_defines.h \
 /usr/include/c++/16/bits/atomic_wait.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/gthr.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h /usr/include/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_itimerspec.h /usr/include/bits/setjmp.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/qt6/QtCore/qconstructormacros.h \
 /usr/include/qt6/QtCore/qdarwinhelpers.h \
 /usr/include/qt6/QtCore/qexceptionhandling.h \
 /usr/include/qt6/QtCore/qforeach.h \
 /usr/include/qt6/QtCore/qttypetraits.h /usr/include/c++/16/optional \
 /usr/include/c++/16/exception /usr/include/c++/16/bits/exception_ptr.h \
 /usr/include/c++/16/bits/cxxabi_init_exception.h \
 /usr/include/c++/16/typeinfo /usr/include/c++/16/bits/hash_bytes.h \
 /usr/include/c++/16/bits/nested_exception.h \
 /usr/include/c++/16/bits/enable_special_members.h \
 /usr/include/c++/16/bits/functional_hash.h /usr/include/c++/16/tuple \
 /usr/include/c++/16/bits/uses_allocator.h /usr/include/c++/16/variant \
 /usr/include/c++/16/bits/monostate.h \
 /usr/include/c++/16/bits/parse_numbers.h \
 /usr/include/qt6/QtCore/qfunctionpointer.h \
 /usr/include/qt6/QtCore/qglobalstatic.h \
 /usr/include/qt6/QtCore/qmalloc.h /usr/include/qt6/QtCore/qminmax.h \
 /usr/include/qt6/QtCore/qnumeric.h /usr/include/c++/16/cmath \
 /usr/include/c++/16/bits/requires_hosted.h /usr/include/math.h \
 /usr/include/bits/math-vector.h /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h /usr/include/bits/mathcalls-macros.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/bits/mathcalls-narrow.h \
 /usr/include/bits/iscanonical.h /usr/include/c++/16/bits/specfun.h \
 /usr/include/c++/16/bits/stdexcept_throw.h \
 /usr/include/c++/16/bits/stdexcept_throwfwd.h \
 /usr/include/c++/16/tr1/gamma.tcc \
 /usr/include/c++/16/tr1/special_function_util.h \
 /usr/include/c++/16/tr1/bessel_function.tcc \
 /usr/include/c++/16/tr1/beta_function.tcc \
 /usr/include/c++/16/tr1/ell_integral.tcc \
 /usr/include/c++/16/tr1/exp_integral.tcc \
 /usr/include/c++/16/tr1/hypergeometric.tcc \
 /usr/include/c++/16/tr1/legendre_function.tcc \
 /usr/include/c++/16/tr1/modified_bessel_func.tcc \
 /usr/include/c++/16/tr1/poly_hermite.tcc \
 /usr/include/c++/16/tr1/poly_laguerre.tcc \
 /usr/include/c++/16/tr1/riemann_zeta.tcc \
 /usr/include/qt6/QtCore/q20type_traits.h \
 /usr/include/qt6/QtCore/qoverload.h /usr/include/qt6/QtCore/qswap.h \
 /usr/include/qt6/QtCore/qtenvironmentvariables.h \
 /usr/include/qt6/QtCore/qtresource.h \
 /usr/include/qt6/QtCore/qttranslation.h \
 /usr/include/qt6/QtCore/qversiontagging.h \
 /usr/include/qt6/QtGui/qtgui-config.h \
 /usr/include/qt6/QtGui/qtguiexports.h \
 /usr/include/qt6/QtWidgets/qtwidgets-config.h \
 /usr/include/qt6/QtWidgets/qtwidgetsexports.h \
 /usr/include/qt6/QtWidgets/qwidget.h \
 /usr/include/qt6/QtGui/qwindowdefs.h \
 /usr/include/qt6/QtCore/qobjectdefs.h \
 /usr/include/qt6/QtCore/qnamespace.h /usr/include/qt6/QtCore/qcompare.h \
 /usr/include/qt6/QtCore/qstdlibdetection.h \
 /usr/include/qt6/QtCore/qcomparehelpers.h /usr/include/c++/16/functional \
 /usr/include/c++/16/bits/refwrap.h \
 /usr/include/c++/16/bits/std_function.h \
 /usr/include/c++/16/bits/functexcept.h /usr/include/c++/16/unordered_map \
 /usr/include/c++/16/bits/unordered_map.h \
 /usr/include/c++/16/bits/hashtable.h \
 /usr/include/c++/16/bits/hashtable_policy.h \
 /usr/include/c++/16/ext/aligned_buffer.h \
 /usr/include/c++/16/ext/alloc_traits.h \
 /usr/include/c++/16/bits/alloc_traits.h \
 /usr/include/c++/16/bits/memoryfwd.h \
 /usr/include/c++/16/bits/allocator.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/c++allocator.h \
 /usr/include/c++/16/bits/new_allocator.h \
 /usr/include/c++/16/bits/new_throw.h \
 /usr/include/c++/16/bits/node_handle.h \
 /usr/include/c++/16/bits/range_access.h \
 /usr/include/c++/16/bits/erase_if.h \
 /usr/include/c++/16/bits/memory_resource.h \
 /usr/include/c++/16/bits/uses_allocator_args.h \
 /usr/include/c++/16/vector /usr/include/c++/16/bits/stl_uninitialized.h \
 /usr/include/c++/16/bits/stl_vector.h \
 /usr/include/c++/16/bits/stl_bvector.h \
 /usr/include/c++/16/bits/vector.tcc /usr/include/c++/16/array \
 /usr/include/c++/16/bits/binders.h \
 /usr/include/qt6/QtCore/qtmetamacros.h \
 /usr/include/qt6/QtCore/qobjectdefs_impl.h \
 /usr/include/qt6/QtCore/qfunctionaltools_impl.h \
 /usr/include/c++/16/memory \
 /usr/include/c++/16/bits/stl_raw_storage_iter.h \
 /usr/include/c++/16/bits/align.h /usr/include/c++/16/bits/unique_ptr.h \
 /usr/include/c++/16/bits/ostream.h /usr/include/c++/16/ios \
 /usr/include/c++/16/iosfwd /usr/include/c++/16/bits/stringfwd.h \
 /usr/include/c++/16/bits/postypes.h /usr/include/c++/16/cwchar \
 /usr/include/wchar.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /usr/include/bits/types/wint_t.h /usr/include/bits/types/mbstate_t.h \
 /usr/include/bits/types/__mbstate_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/c++/16/bits/char_traits.h \
 /usr/include/c++/16/bits/localefwd.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/c++locale.h \
 /usr/include/c++/16/clocale /usr/include/locale.h \
 /usr/include/bits/locale.h /usr/include/c++/16/cctype \
 /usr/include/ctype.h /usr/include/c++/16/bits/ios_base.h \
 /usr/include/c++/16/ext/atomicity.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/atomic_word.h \
 /usr/include/sys/single_threaded.h \
 /usr/include/c++/16/bits/locale_classes.h /usr/include/c++/16/string \
 /usr/include/c++/16/bits/ostream_insert.h \
 /usr/include/c++/16/bits/cxxabi_forced.h \
 /usr/include/c++/16/bits/basic_string.h /usr/include/c++/16/string_view \
 /usr/include/c++/16/bits/string_view.tcc \
 /usr/include/c++/16/ext/string_conversions.h /usr/include/c++/16/cstdio \
 /usr/include/stdio.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__fpos64_t.h \
 /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/c++/16/cerrno \
 /usr/include/errno.h /usr/include/bits/errno.h \
 /usr/include/linux/errno.h /usr/include/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/bits/types/error_t.h /usr/include/c++/16/bits/charconv.h \
 /usr/include/c++/16/bits/basic_string.tcc \
 /usr/include/c++/16/bits/locale_classes.tcc \
 /usr/include/c++/16/system_error \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/error_constants.h \
 /usr/include/c++/16/stdexcept \
 /usr/include/c++/16/bits/stdexcept_except.h \
 /usr/include/c++/16/streambuf /usr/include/c++/16/bits/streambuf.tcc \
 /usr/include/c++/16/bits/basic_ios.h \
 /usr/include/c++/16/bits/locale_facets.h /usr/include/c++/16/cwctype \
 /usr/include/wctype.h /usr/include/bits/wctype-wchar.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/ctype_base.h \
 /usr/include/c++/16/bits/streambuf_iterator.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/ctype_inline.h \
 /usr/include/c++/16/bits/locale_facets.tcc \
 /usr/include/c++/16/bits/basic_ios.tcc \
 /usr/include/c++/16/bits/shared_ptr.h \
 /usr/include/c++/16/bits/shared_ptr_base.h \
 /usr/include/c++/16/bits/allocated_ptr.h \
 /usr/include/c++/16/ext/concurrence.h \
 /usr/include/c++/16/bits/shared_ptr_atomic.h \
 /usr/include/c++/16/backward/auto_ptr.h \
 /usr/include/c++/16/bits/ranges_uninitialized.h \
 /usr/include/c++/16/pstl/glue_memory_defs.h \
 /usr/include/qt6/QtCore/qobject.h /usr/include/qt6/QtCore/qstring.h \
 /usr/include/qt6/QtCore/qchar.h /usr/include/qt6/QtCore/qbytearray.h \
 /usr/include/qt6/QtCore/qrefcount.h /usr/include/qt6/QtCore/qarraydata.h \
 /usr/include/qt6/QtCore/qpair.h /usr/include/string.h \
 /usr/include/strings.h /usr/include/qt6/QtCore/qarraydatapointer.h \
 /usr/include/qt6/QtCore/qarraydataops.h \
 /usr/include/qt6/QtCore/qcontainertools_impl.h \
 /usr/include/qt6/QtCore/qxptype_traits.h \
 /usr/include/qt6/QtCore/q23type_traits.h /usr/include/c++/16/cstring \
 /usr/include/c++/16/iterator /usr/include/c++/16/bits/stream_iterator.h \
 /usr/include/qt6/QtCore/q20functional.h \
 /usr/include/qt6/QtCore/q20memory.h /usr/include/qt6/QtCore/q17memory.h \
 /usr/include/qt6/QtCore/qbytearrayalgorithms.h \
 /usr/include/qt6/QtCore/qbytearrayview.h \
 /usr/include/qt6/QtCore/qstringfwd.h /usr/include/c++/16/stdlib.h \
 /usr/include/qt6/QtCore/qlatin1stringview.h \
 /usr/include/qt6/QtCore/qstringview.h \
 /usr/include/qt6/QtCore/qstringalgorithms.h \
 /usr/include/qt6/QtCore/qanystringview.h \
 /usr/include/qt6/QtCore/qutf8stringview.h \
 /usr/include/qt6/QtCore/qstringtokenizer.h \
 /usr/include/qt6/QtCore/qstringbuilder.h \
 /usr/include/qt6/QtCore/qstringconverter.h \
 /usr/include/qt6/QtCore/qstringconverter_base.h \
 /usr/include/qt6/QtCore/qlist.h /usr/include/qt6/QtCore/qhashfunctions.h \
 /usr/include/qt6/QtCore/qbitarray.h /usr/include/c++/16/numeric \
 /usr/include/c++/16/bits/stl_numeric.h \
 /usr/include/c++/16/pstl/glue_numeric_defs.h \
 /usr/include/qt6/QtCore/qiterator.h /usr/include/c++/16/ranges \
 /usr/include/c++/16/span /usr/include/qt6/QtCore/qscopeguard.h \
 /usr/include/qt6/QtCore/qbytearraylist.h \
 /usr/include/qt6/QtCore/qstringlist.h \
 /usr/include/qt6/QtCore/qalgorithms.h /usr/include/qt6/QtCore/q20bit.h \
 /usr/include/qt6/QtCore/qstringmatcher.h \
 /usr/include/qt6/QtCore/qscopedpointer.h \
 /usr/include/qt6/QtCore/qmetatype.h \
 /usr/include/qt6/QtCore/qdatastream.h \
 /usr/include/qt6/QtCore/qiodevicebase.h \
 /usr/include/qt6/QtCore/qfloat16.h /usr/include/qt6/QtCore/qmath.h \
 /usr/include/qt6/QtCore/qtformat_impl.h /usr/include/c++/16/format \
 /usr/include/c++/16/charconv /usr/include/c++/16/locale \
 /usr/include/c++/16/bits/locale_facets_nonio.h /usr/include/c++/16/ctime \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/time_members.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/messages_members.h \
 /usr/include/libintl.h /usr/include/c++/16/bits/codecvt.h \
 /usr/include/c++/16/bits/locale_facets_nonio.tcc \
 /usr/include/c++/16/bits/locale_conv.h \
 /usr/include/c++/16/bits/formatfwd.h /usr/include/c++/16/bits/unicode.h \
 /usr/include/c++/16/bits/unicode-data.h \
 /usr/include/qt6/QtCore/qiterable.h \
 /usr/include/qt6/QtCore/qtaggedpointer.h \
 /usr/include/qt6/QtCore/qmetacontainer.h \
 /usr/include/qt6/QtCore/qcontainerinfo.h /usr/include/c++/16/list \
 /usr/include/c++/16/bits/stl_list.h /usr/include/c++/16/bits/list.tcc \
 /usr/include/c++/16/map /usr/include/c++/16/bits/stl_tree.h \
 /usr/include/c++/16/bits/stl_map.h \
 /usr/include/c++/16/bits/stl_multimap.h \
 /usr/include/qt6/QtCore/qobject_impl.h \
 /usr/include/qt6/QtCore/qbindingstorage.h /usr/include/c++/16/chrono \
 /usr/include/c++/16/bits/chrono.h /usr/include/c++/16/ratio \
 /usr/include/c++/16/sstream /usr/include/c++/16/istream \
 /usr/include/c++/16/ostream /usr/include/c++/16/bits/ostream_print.h \
 /usr/include/c++/16/bits/ostream.tcc \
 /usr/include/c++/16/bits/istream.tcc \
 /usr/include/c++/16/bits/sstream.tcc \
 /usr/include/c++/16/bits/chrono_io.h /usr/include/qt6/QtCore/qmargins.h \
 /usr/include/qt6/QtCore/qcheckedint_impl.h \
 /usr/include/qt6/QtCore/q23utility.h \
 /usr/include/qt6/QtCore/q20utility.h /usr/include/qt6/QtGui/qaction.h \
 /usr/include/qt6/QtGui/qkeysequence.h /usr/include/qt6/QtGui/qicon.h \
 /usr/include/qt6/QtCore/qsize.h /usr/include/qt6/QtGui/qpixmap.h \
 /usr/include/qt6/QtGui/qpaintdevice.h /usr/include/qt6/QtCore/qrect.h \
 /usr/include/qt6/QtCore/qpoint.h /usr/include/qt6/QtGui/qcolor.h \
 /usr/include/qt6/QtGui/qrgb.h /usr/include/qt6/QtGui/qrgba64.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/limits.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix1_lim.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/posix2_lim.h /usr/include/bits/xopen_lim.h \
 /usr/include/bits/uio_lim.h /usr/include/qt6/QtCore/qshareddata.h \
 /usr/include/qt6/QtGui/qimage.h /usr/include/qt6/QtGui/qpixelformat.h \
 /usr/include/qt6/QtGui/qtransform.h /usr/include/qt6/QtGui/qpolygon.h \
 /usr/include/qt6/QtGui/qregion.h /usr/include/qt6/QtCore/qspan.h \
 /usr/include/c++/16/cassert /usr/include/qt6/QtCore/q20iterator.h \
 /usr/include/qt6/QtCore/qline.h /usr/include/qt6/QtCore/qvariant.h \
 /usr/include/qt6/QtCore/qdebug.h /usr/include/qt6/QtCore/qtextstream.h \
 /usr/include/qt6/QtCore/qcontiguouscache.h /usr/include/c++/16/climits \
 /usr/include/qt6/QtCore/qsharedpointer.h \
 /usr/include/qt6/QtCore/qsharedpointer_impl.h /usr/include/c++/16/set \
 /usr/include/c++/16/bits/stl_set.h \
 /usr/include/c++/16/bits/stl_multiset.h \
 /usr/include/c++/16/unordered_set \
 /usr/include/c++/16/bits/unordered_set.h /usr/include/qt6/QtCore/qmap.h \
 /usr/include/qt6/QtCore/qshareddata_impl.h \
 /usr/include/qt6/QtCore/qset.h /usr/include/qt6/QtCore/qhash.h \
 /usr/include/qt6/QtCore/qvarlengtharray.h \
 /usr/include/qt6/QtCore/qalloc.h /usr/include/qt6/QtGui/qpalette.h \
 /usr/include/qt6/QtGui/qbrush.h /usr/include/qt6/QtGui/qfont.h \
 /usr/include/qt6/QtCore/qendian.h /usr/include/qt6/QtGui/qfontmetrics.h \
 /usr/include/qt6/QtGui/qfontinfo.h \
 /usr/include/qt6/QtGui/qfontvariableaxis.h \
 /usr/include/qt6/QtWidgets/qsizepolicy.h \
 /usr/include/qt6/QtGui/qcursor.h /usr/include/qt6/QtGui/qbitmap.h \
 /home/shs/Code/MusiK/CPP/src/audio_output.h \
 /usr/include/qt6/QtMultimedia/QAudioBuffer \
 /usr/include/qt6/QtMultimedia/qaudiobuffer.h \
 /usr/include/qt6/QtMultimedia/qaudioformat.h \
 /usr/include/qt6/QtMultimedia/qtmultimediaglobal.h \
 /usr/include/qt6/QtMultimedia/qtmultimedia-config.h \
 /usr/include/qt6/QtMultimedia/qtmultimediaexports.h \
 /usr/include/qt6/QtMultimedia/qtaudio.h \
 /usr/include/qt6/QtMultimedia/qaudio.h \
 /usr/include/qt6/QtMultimedia/QAudioSink \
 /usr/include/qt6/QtMultimedia/qaudiosink.h \
 /usr/include/qt6/QtMultimedia/qaudiodevice.h \
 /usr/include/qt6/QtCore/qiodevice.h \
 /usr/include/qt6/QtMultimedia/QAudioBufferOutput \
 /usr/include/qt6/QtMultimedia/qaudiobufferoutput.h \
 /usr/include/qt6/QtMultimedia/QAudioOutput \
 /usr/include/qt6/QtMultimedia/qaudiooutput.h \
 /usr/include/qt6/QtMultimedia/QMediaPlayer \
 /usr/include/qt6/QtMultimedia/qmediaplayer.h \
 /usr/include/qt6/QtCore/qurl.h \
 /usr/include/qt6/QtMultimedia/QMediaDevices \
 /usr/include/qt6/QtMultimedia/qmediadevices.h \
 /usr/include/qt6/QtWidgets/QComboBox \
 /usr/include/qt6/QtWidgets/qcombobox.h \
 /usr/include/qt6/QtWidgets/qabstractitemdelegate.h \
 /usr/include/qt6/QtWidgets/qstyleoption.h \
 /usr/include/qt6/QtCore/qlocale.h \
 /usr/include/qt6/QtWidgets/qabstractspinbox.h \
 /usr/include/qt6/QtGui/qvalidator.h \
 /usr/include/qt6/QtCore/qregularexpression.h \
 /usr/include/qt6/QtWidgets/qslider.h \
 /usr/include/qt6/QtWidgets/qabstractslider.h \
 /usr/include/qt6/QtWidgets/qstyle.h /usr/include/qt6/QtWidgets/qtabbar.h \
 /usr/include/qt6/QtWidgets/qrubberband.h \
 /usr/include/qt6/QtWidgets/qframe.h \
 /usr/include/qt6/QtCore/qabstractitemmodel.h \
 /usr/include/qt6/QtWidgets/QFormLayout \
 /usr/include/qt6/QtWidgets/qformlayout.h \
 /usr/include/qt6/QtWidgets/QLayout /usr/include/qt6/QtWidgets/qlayout.h \
 /usr/include/qt6/QtWidgets/qlayoutitem.h \
 /usr/include/qt6/QtWidgets/qboxlayout.h \
 /usr/include/qt6/QtWidgets/qgridlayout.h \
 /usr/include/qt6/QtCore/QSignalBlocker /usr/include/qt6/QtCore/QSettings \
 /usr/include/qt6/QtCore/qsettings.h /usr/include/qt6/QtCore/QTimer \
 /usr/include/qt6/QtCore/qtimer.h /usr/include/qt6/QtCore/qbasictimer.h \
 /usr/include/qt6/QtCore/qabstracteventdispatcher.h \
 /usr/include/qt6/QtCore/qeventloop.h \
 /usr/include/qt6/QtCore/qdeadlinetimer.h \
 /usr/include/qt6/QtWidgets/QToolTip \
 /usr/include/qt6/QtWidgets/qtooltip.h \
 /usr/include/qt6/QtWidgets/QApplication \
 /usr/include/qt6/QtWidgets/qapplication.h \
 /usr/include/qt6/QtCore/qcoreapplication.h \
 /usr/include/qt6/QtCore/qcoreevent.h \
 /usr/include/qt6/QtCore/qnativeinterface.h \
 /usr/include/qt6/QtCore/qcoreapplication_platform.h \
 /usr/include/qt6/QtGui/qguiapplication.h \
 /usr/include/qt6/QtGui/qinputmethod.h \
 /usr/include/qt6/QtGui/qguiapplication_platform.h \
 /usr/include/qt6/QtWidgets/QMainWindow \
 /usr/include/qt6/QtWidgets/qmainwindow.h \
 /usr/include/qt6/QtOpenGLWidgets/QOpenGLWidget \
 /usr/include/qt6/QtOpenGLWidgets/qopenglwidget.h \
 /usr/include/qt6/QtOpenGLWidgets/qtopenglwidgetsglobal.h \
 /usr/include/qt6/QtOpenGLWidgets/qtopenglwidgetsexports.h \
 /usr/include/qt6/QtWidgets/QWidget /usr/include/qt6/QtGui/QSurfaceFormat \
 /usr/include/qt6/QtGui/qsurfaceformat.h /usr/include/qt6/QtGui/qopengl.h \
 /usr/include/GL/gl.h /usr/include/qt6/QtGui/qopenglext.h \
 /usr/include/inttypes.h \
 /usr/include/qt6/QtOpenGL/QOpenGLFunctions_3_3_Core \
 /usr/include/qt6/QtOpenGL/qopenglfunctions_3_3_core.h \
 /usr/include/qt6/QtOpenGL/qtopenglglobal.h \
 /usr/include/qt6/QtOpenGL/qtopenglexports.h \
 /usr/include/qt6/QtOpenGL/QOpenGLVersionProfile \
 /usr/include/qt6/QtOpenGL/qopenglversionprofile.h \
 /usr/include/qt6/QtOpenGL/QOpenGLVersionFunctions \
 /usr/include/qt6/QtOpenGL/qopenglversionfunctions.h \
 /usr/include/qt6/QtGui/qopenglcontext.h \
 /usr/include/qt6/QtGui/qopenglcontext_platform.h \
 /usr/include/qt6/QtOpenGL/QOpenGLShaderProgram \
 /usr/include/qt6/QtOpenGL/qopenglshaderprogram.h \
 /usr/include/qt6/QtGui/qvector2d.h /usr/include/qt6/QtGui/qvectornd.h \
 /usr/include/qt6/QtGui/qvector3d.h /usr/include/qt6/QtGui/qvector4d.h \
 /usr/include/qt6/QtGui/qmatrix4x4.h \
 /usr/include/qt6/QtGui/qgenericmatrix.h \
 /usr/include/qt6/QtMultimedia/QAudioFormat \
 /usr/include/qt6/QtWidgets/QBoxLayout \
 /usr/include/qt6/QtWidgets/QPushButton \
 /usr/include/qt6/QtWidgets/qpushbutton.h \
 /usr/include/qt6/QtWidgets/qabstractbutton.h \
 /usr/include/qt6/QtWidgets/QListWidget \
 /usr/include/qt6/QtWidgets/qlistwidget.h \
 /usr/include/qt6/QtWidgets/qlistview.h \
 /usr/include/qt6/QtWidgets/qabstractitemview.h \
 /usr/include/qt6/QtWidgets/qabstractscrollarea.h \
 /usr/include/qt6/QtCore/qitemselectionmodel.h \
 /usr/include/qt6/QtWidgets/QFileDialog \
 /usr/include/qt6/QtWidgets/qfiledialog.h /usr/include/qt6/QtCore/qdir.h \
 /usr/include/qt6/QtCore/qdirlisting.h \
 /usr/include/qt6/QtCore/qfiledevice.h /usr/include/c++/16/filesystem \
 /usr/include/c++/16/bits/fs_fwd.h /usr/include/c++/16/bits/fs_path.h \
 /usr/include/c++/16/iomanip /usr/include/c++/16/bits/quoted_string.h \
 /usr/include/c++/16/codecvt /usr/include/c++/16/bits/fs_dir.h \
 /usr/include/c++/16/bits/fs_ops.h /usr/include/qt6/QtCore/qdatetime.h \
 /usr/include/qt6/QtCore/qcalendar.h /usr/include/qt6/QtCore/qfile.h \
 /usr/include/qt6/QtCore/qfileinfo.h /usr/include/qt6/QtCore/qtimezone.h \
 /usr/include/qt6/QtWidgets/qdialog.h /usr/include/qt6/QtCore/QFile \
 /usr/include/qt6/QtCore/QFileInfo /usr/include/qt6/QtCore/QDir \
 /usr/include/qt6/QtCore/QStandardPaths \
 /usr/include/qt6/QtCore/qstandardpaths.h \
 /usr/include/qt6/QtCore/QElapsedTimer \
 /usr/include/qt6/QtCore/qelapsedtimer.h /usr/include/qt6/QtGui/QPainter \
 /usr/include/qt6/QtGui/qpainter.h /usr/include/qt6/QtGui/qtextoption.h \
 /usr/include/qt6/QtGui/qpen.h /usr/include/qt6/QtCore/QRandomGenerator \
 /usr/include/qt6/QtCore/qrandom.h /usr/include/c++/16/random \
 /usr/include/c++/16/bits/random.h \
 /usr/include/c++/16/x86_64-pc-linux-gnu/bits/opt_random.h \
 /usr/include/c++/16/bits/random.tcc /usr/include/qt6/QtWidgets/QSlider \
 /usr/include/qt6/QtWidgets/QLabel /usr/include/qt6/QtWidgets/qlabel.h \
 /usr/include/qt6/QtGui/qpicture.h /usr/include/qt6/QtGui/qtextdocument.h \
 /usr/include/qt6/QtGui/QCloseEvent /usr/include/qt6/QtGui/qevent.h \
 /usr/include/qt6/QtGui/qeventpoint.h \
 /usr/include/qt6/QtGui/qpointingdevice.h \
 /usr/include/qt6/QtGui/qinputdevice.h /usr/include/qt6/QtGui/qscreen.h \
 /usr/include/qt6/QtCore/QList /usr/include/qt6/QtCore/QObject \
 /usr/include/qt6/QtCore/QRect /usr/include/qt6/QtCore/QSize \
 /usr/include/qt6/QtCore/QSizeF /usr/include/qt6/QtGui/QTransform \
 /usr/include/qt6/QtGui/qscreen_platform.h \
 /usr/include/qt6/QtGui/QKeyEvent /usr/include/qt6/QtWidgets/QMessageBox \
 /usr/include/qt6/QtWidgets/qmessagebox.h \
 /usr/include/qt6/QtWidgets/qdialogbuttonbox.h \
 /usr/include/qt6/QtWidgets/QToolBar \
 /usr/include/qt6/QtWidgets/qtoolbar.h \
 /usr/include/qt6/QtGui/QSurfaceFormat /usr/include/qt6/QtCore/QDateTime \
 /usr/include/qt6/QtGui/QVector2D /usr/include/qt6/QtGui/QVector3D \
 /usr/include/qt6/QtGui/QVector4D /usr/include/qt6/QtCore/QUrl \
 /usr/include/qt6/QtGui/QMouseEvent /usr/include/qt6/QtWidgets/QMenu \
 /usr/include/qt6/QtWidgets/qmenu.h \
 /usr/include/qt6/QtMultimedia/QMediaMetaData \
 /usr/include/qt6/QtMultimedia/qmediametadata.h \
 /usr/include/qt6/QtCore/QDirIterator \
 /usr/include/qt6/QtCore/qdiriterator.h /usr/include/qt6/QtCore/QSet \
 /usr/include/qt6/QtWidgets/QProgressBar \
 /usr/include/qt6/QtWidgets/qprogressbar.h \
 /usr/include/qt6/QtWidgets/QFrame /usr/include/qt6/QtWidgets/QGroupBox \
 /usr/include/qt6/QtWidgets/qgroupbox.h \
 /usr/include/qt6/QtWidgets/QStatusBar \
 /usr/include/qt6/QtWidgets/qstatusbar.h \
 /usr/include/qt6/QtGui/QFontMetrics /usr/include/qt6/QtGui/QPainterPath \
 /usr/include/qt6/QtGui/qpainterpath.h /usr/include/qt6/QtGui/QShortcut \
 /usr/include/qt6/QtGui/qshortcut.h /usr/include/qt6/QtGui/QKeySequence \
 /usr/include/qt6/QtWidgets/QDialog \
 /home/shs/Code/MusiK/CPP/src/track_information.h \
 /usr/include/qt6/QtCore/QFutureWatcher \
 /usr/include/qt6/QtCore/qfuturewatcher.h \
 /usr/include/qt6/QtCore/qfuture.h \
 /usr/include/qt6/QtCore/qfutureinterface.h \
 /usr/include/qt6/QtCore/qmutex.h /usr/include/qt6/QtCore/qtsan_impl.h \
 /usr/include/qt6/QtCore/qresultstore.h \
 /usr/include/qt6/QtCore/qfuture_impl.h \
 /usr/include/qt6/QtCore/qthreadpool.h /usr/include/qt6/QtCore/qthread.h \
 /usr/include/c++/16/future /usr/include/c++/16/mutex \
 /usr/include/c++/16/bits/std_mutex.h \
 /usr/include/c++/16/bits/unique_lock.h \
 /usr/include/c++/16/condition_variable /usr/include/c++/16/stop_token \
 /usr/include/c++/16/bits/std_thread.h /usr/include/c++/16/semaphore \
 /usr/include/c++/16/bits/semaphore_base.h \
 /usr/include/c++/16/bits/atomic_timed_wait.h \
 /usr/include/c++/16/bits/this_thread_sleep.h /usr/include/sys/time.h \
 /usr/include/c++/16/bits/atomic_futex.h \
 /usr/include/qt6/QtCore/qrunnable.h /usr/include/qt6/QtCore/qexception.h \
 /usr/include/qt6/QtCore/qpromise.h /usr/include/qt6/QtGui/QImageReader \
 /usr/include/qt6/QtGui/qimagereader.h \
 /usr/include/qt6/QtGui/qimageiohandler.h \
 /usr/include/qt6/QtCore/qplugin.h /usr/include/qt6/QtCore/qpointer.h \
 /usr/include/qt6/QtCore/qjsonobject.h \
 /usr/include/qt6/QtCore/qjsonvalue.h \
 /usr/include/qt6/QtCore/qcborvalue.h \
 /usr/include/qt6/QtCore/qcborcommon.h /usr/include/qt6/QtCore/quuid.h \
 /usr/include/qt6/QtCore/qjsondocument.h \
 /usr/include/qt6/QtCore/qjsonparseerror.h \
 /usr/include/qt6/QtCore/q20algorithm.h \
 /usr/include/qt6/QtCore/qfactoryinterface.h \
 /usr/include/qt6/QtWidgets/QScrollArea \
 /usr/include/qt6/QtWidgets/qscrollarea.h \
 /usr/include/qt6/QtConcurrent/QtConcurrentRun \
 /usr/include/qt6/QtConcurrent/qtconcurrentrun.h \
 /usr/include/qt6/QtConcurrent/qtconcurrentcompilertest.h \
 /usr/include/qt6/QtConcurrent/qtconcurrent_global.h \
 /usr/include/qt6/QtConcurrent/qtconcurrentexports.h \
 /usr/include/qt6/QtConcurrent/qtconcurrentrunbase.h \
 /usr/include/qt6/QtConcurrent/qtconcurrentstoredfunctioncall.h \
 /usr/include/qt6/QtGui/QFont /usr/include/qt6/QtCore/QPointer \
 /usr/include/qt6/QtWidgets/QGraphicsDropShadowEffect \
 /usr/include/qt6/QtWidgets/qgraphicseffect.h /usr/include/c++/16/complex \
 /usr/include/qt6/QtWidgets/QSpinBox \
 /usr/include/qt6/QtWidgets/qspinbox.h \
 /usr/include/qt6/QtGui/QLinearGradient \
 /usr/include/qt6/QtWidgets/QLineEdit \
 /usr/include/qt6/QtWidgets/qlineedit.h \
 /usr/include/qt6/QtGui/qtextcursor.h \
 /usr/include/qt6/QtGui/qtextformat.h \
 /usr/include/qt6/QtWidgets/QCheckBox \
 /usr/include/qt6/QtWidgets/qcheckbox.h \
 /usr/include/qt6/QtWidgets/QColorDialog \
 /usr/include/qt6/QtWidgets/qcolordialog.h \
 /usr/include/qt6/QtWidgets/QStyle \
 /usr/include/qt6/QtWidgets/QGraphicsOpacityEffect \
 /usr/include/qt6/QtGui/QFontDatabase \
 /usr/include/qt6/QtGui/qfontdatabase.h /usr/include/qt6/QtGui/QScreen \
 /usr/include/qt6/QtCore/QDebug
